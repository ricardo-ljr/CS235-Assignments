#include <iostream>
using namespace std;

int main()
{
    int userOption;

    cin >> userOption;
    cout << "Hello world" << endl;
    cout << "Your option was: " << userOption << endl;
}
